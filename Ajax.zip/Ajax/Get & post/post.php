<?php

$name = $_POST['name'];
$age = $_POST['age'];


echo "My name is ".$name. " And my age is " .$age;
?>